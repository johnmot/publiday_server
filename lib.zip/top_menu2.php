<div id='header_bar'>
	<div class='zeta-menu-bar'>
	  <ul class="zeta-menu">
		<li><a href="../notice/list.php">공지사항</a></li>
		<li><a href="../free/list.php">고객센터</a></li>
	  </ul>
	</div>
</div>
<div id='header_logo'>
	<a href="/"><img src="../img/h_logo.png" width='150'/></a>
</div>
