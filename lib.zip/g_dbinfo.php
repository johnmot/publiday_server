<?php
$db['host'] = "localhost";
$db['name'] = "etdatabase";
$db['user'] = "etowner";
$db['pass'] = "!dlxlelql";
$db['port'] = "3306";
?>

